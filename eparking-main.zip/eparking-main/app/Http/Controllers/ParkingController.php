<?php

namespace App\Http\Controllers;

use App\Models\ParkingSpace;
use Illuminate\Http\Request;

class ParkingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $parking_spaces = ParkingSpace::all(['*']);
        // dd($parking_spaces);
        return view('parking.index')->with('parking_spaces', $parking_spaces);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view("parking.add");
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $result =  ParkingSpace::create([
            'name' => $request->name,
            'category' => $request->category,
            'vehicle_groups' => json_encode($request->vehicleGroups)
        ]);
        $id = $result->id;
        return redirect("/parking/view/$id")->with('id', $result->id);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $parking_space = ParkingSpace::where('id', $id)->first();

        return view('parking.view')->with('parkingSpace', $parking_space);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $parking_space = ParkingSpace::where('id', $id)->first();

        return view('parking.edit')->with('parkingSpace', $parking_space);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        // dd($id);
        $affected_rows = ParkingSpace::where('id', $id)
            ->update(
                [
                    'name' => $request->name,
                    'category' => $request->category,
                    'vehicle_groups' => json_encode($request->vehicleGroups)
                ]
            );


        return redirect("/parking/view/$id")->with('id', $id);

        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $result = ParkingSpace::where('id', $id)->delete();
        return redirect("parking");
    }
}

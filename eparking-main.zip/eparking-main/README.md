# eparking
A web based parking solution for drivers and parking space providers
## Getting Started
Follow the steps below to get the project running on your machine
### Step 1: Clone the project
Open terminal in the folder where you want to clone the project and run the following command
```sh
git clone https://github.com/code-lords/eparking.git
```
This will install the project on your machine
Then go to the project directory
```sh
cd eparking
```

### Step 2: Install the composer packages
Install all the relevant dependencies using composer

```sh
composer install
```
### Step 3: Copy the .env.example to .env 
Make a copy of the .env.example file and rename it to .env inside your project root.
```sh
cp .env.example .env
```
If you are using command prompt use the command below
```sh
copy .env.example .env
```
### Step 4: Generate your app key
Run the following command to generate your app key
```sh
php artisan key:generate
```
Then we are done setting up the app
### Step 5: Run the application 😍
Run the following comman dto start the app
```sh
php artisan serve
```
Then go to the browser and Visit enter the  url[http://localhost:8000]
### Conclusion
You can now edit create the database and edit the details in the .env file 
### Happy Hacking!!!

@extends('layouts.app')
@section('content')
{{-- Complex / Extra tool / Footer --}}
<x-adminlte-card title="View Parking Space - {{ $parkingSpace->name}}" theme="dark" icon="fas fa-lg fa-car">
    <div class="row">

        <div class="col-sm-6">

            <x-adminlte-callout theme="info" title="Total Parking slots">
                100
            </x-adminlte-callout>
            <x-adminlte-callout theme="info" title="Booked">
                90
            </x-adminlte-callout>

        </div>
        <div class="card col-sm-6">
            <h6 class="card-header"><b>Parking Space Details</b></h6>
            <div class="card-body">
                <p>{{$parkingSpace->name}}</p>
                <p>{{$parkingSpace->vehicle_groups}}</p>
                <p>{{$parkingSpace->category}}</p>
                <p>Location <b>Kampala Uganada</b></p>
            </div>
            <div class="row card-footer ">
                <a href="{{route('parking.edit',$parkingSpace->id)}}" class="mr-2">
                    <x-adminlte-button label="Edit" theme="success" icon="fas fa-lg fa-pen" />

                </a>

                <a href="{{route('parking.delete',$parkingSpace->id)}}" onclick="return confirm('Do you want to delete this parking space?')">
                    <x-adminlte-button label="Delete" theme="danger" icon="fas fa-lg fa-trash" />

                </a>

            </div>


        </div>
        <div class="row">
            <x-adminlte-card>

            </x-adminlte-card>
        </div>
    </div>


    <img src="" alt="">
</x-adminlte-card>
<x-adminlte-card title="Recent Activity " theme="light" icon="fas fa-lg fa-info">
</x-adminlte-card>
@endsection
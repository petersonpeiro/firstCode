@extends('layouts.app')
@section('content')
<x-adminlte-card title="" theme="" title="{{ __('Parking Spaces') }}">

    <div class="card-body">
        {{-- Setup data for datatables --}}
        @php
        $heads = [
        '#',
        'Name',
        ['label' => 'Category', 'width' => 40],
        ['label' => 'Actions', 'no-export' => true, 'width' => 5],
        ];

        $btnEdit = '<button class="btn btn-xs btn-default text-primary mx-1 shadow" title="Edit">
            <i class="fa fa-lg fa-fw fa-pen"></i>
        </button>';
        $btnDelete = '<button class="btn btn-xs btn-default text-danger mx-1 shadow" title="Delete">
            <i class="fa fa-lg fa-fw fa-trash"></i>
        </button>';
        $btnDetails = '<button class="btn btn-xs btn-default text-teal mx-1 shadow" title="Details">
            <i class="fa fa-lg fa-fw fa-eye"></i>
        </button>';

        $config = [
        'data' => [
        [22, 'John Bender', '+02 (123) 123456789', '<nobr>'.$btnEdit.$btnDelete.$btnDetails.'</nobr>'],
        [19, 'Sophia Clemens', '+99 (987) 987654321', '<nobr>'.$btnEdit.$btnDelete.$btnDetails.'</nobr>'],
        [3, 'Peter Sousa', '+69 (555) 12367345243', '<nobr>'.$btnEdit.$btnDelete.$btnDetails.'</nobr>'],
        ],
        'order' => [[1, 'asc']],
        'columns' => [null, null, null, ['orderable' => false]],
        ];
        @endphp

        {{-- Minimal example / fill data using the component slot --}}
        <x-adminlte-datatable id="table1" :heads="$heads">
            @foreach($parking_spaces as $parking_space)
            <tr>

                <td>{{$parking_space->id}}</td>
                <td>{{$parking_space->name}}</td>
                <td>{{$parking_space->category}}</td>
                <td>
                    <nobr>
                        <a href="{{route('parking.edit',$parking_space->id)}}">
                            <button class="btn btn-xs btn-default text-primary mx-1 shadow" title="Edit">
                                <i class="fa fa-lg fa-fw fa-pen"></i>
                            </button>

                        </a>
                        <a href="{{route('parking.delete',$parking_space->id)}}" onclick="return confirm('Do you want to delete?')">
                            <button class="btn btn-xs btn-default text-danger mx-1 shadow" title="Delete">
                                <i class="fa fa-lg fa-fw fa-trash"></i>
                            </button>

                        </a>
                        <a href="{{route('parking.view',$parking_space->id)}}">
                            <button class="btn btn-xs btn-default text-teal mx-1 shadow" title="Details">
                                <i class="fa fa-lg fa-fw fa-eye"></i>
                            </button>

                        </a>
                    </nobr>
                </td>

            </tr>
            @endforeach
        </x-adminlte-datatable>

        <!-- {{-- Compressed with style options / fill data using the plugin config --}} -->
        <!-- <x-adminlte-datatable id="table2" :heads="$heads" head-theme="dark" :config="$config" striped hoverable bordered compressed /> -->
        <!-- <x-adminlte-button class="btn-flat pull-right" type="submit" label="Submit" theme="success" icon="fas fa-lg fa-save" /> -->


    </div>

</x-adminlte-card>
@endsection
@extends('layouts.app')

@section('content')
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">
                    <h2>
                        {{ __('Add Parking Place') }}
                    </h2>
                </div>

                <div class="card-body">
                    <form action="" method="post">
                        {{-- Example with empty option (for Select) --}}
                        @csrf


                        <x-adminlte-input name="name" placeholder="Name of the place" label="Name" />

                        <x-adminlte-input name="location" placeholder="Enter Location of place" label="Location" />

                        <x-adminlte-select name="category" label="Parking type">
                            <x-adminlte-options :options="['Outdoor', 'Indoor', 'Uncategorized']" disabled="1" empty-option="Select an option..." />
                        </x-adminlte-select>

                        {{-- Example with placeholder (for Select) --}}
                        <!-- <x-adminlte-select name="optionsTest2"> -->
                        <!-- <x-adminlte-options :options="['Option 1', 'Option 2', 'Option 3']" disabled="1" placeholder="Select an option..." /> -->
                        <!-- </x-adminlte-select> -->

                        <!-- {{-- Example with empty option (for Select2) --}} -->
                        <!-- Vehicle groups -->
                        <!-- <x-adminlte-select2 name="vehicleGroups" igroup-size="lg" label-class="text-lightblue" data-placeholder="Select an option..."> -->
                        <!-- <x-slot name="prependSlot"> -->
                        <!-- <div class="input-group-text bg-gradient-info"> -->
                        <!-- <i class="fas fa-car-side"></i> -->
                        <!-- </div> -->
                        <!-- </x-slot> -->
                        <!-- <x-adminlte-options :options="['Car', 'Truck', 'Motorcycle']" empty-option /> -->
                        <!-- </x-adminlte-select2> -->
                        {{-- Vehicle groups --}}
                        @php
                        $options = ['1' => 'Car', '2' => 'Track', '3' => 'Motorcycle'];
                        $selected = [];
                        @endphp
                        <x-adminlte-select id="optionsLangs" name="vehicleGroups[]" label="Vehicle Groups" label-class="text-dark" multiple>
                            <x-slot name="prependSlot">
                                <div class="input-group-text bg-gradient-info">
                                    <i class="fas fa-car-side"></i>
                                </div>
                            </x-slot>
                            <x-adminlte-options :options="$options" :selected="$selected" />
                        </x-adminlte-select>


                        <!-- {{-- Example with multiple selections (for SelectBs) --}}
                        @php
                        $config = [
                        "title" => "Select multiple options...",
                        "liveSearch" => true,
                        "liveSearchPlaceholder" => "Search...",
                        "showTick" => true,
                        "actionsBox" => true,
                        ];
                        @endphp
                        <x-adminlte-select-bs id="optionsCategory" name="optionsCategory[]" label="Categories" label-class="text-danger" :config="$config" multiple>
                            <x-slot name="prependSlot">
                                <div class="input-group-text bg-gradient-red">
                                    <i class="fas fa-tag"></i>
                                </div>
                            </x-slot>
                            <x-adminlte-options :options="['News', 'Sports', 'Science', 'Games']" />
                        </x-adminlte-select-bs> -->
                        <x-adminlte-button class="btn-flat pull-right" type="submit" label="Submit" theme="success" icon="fas fa-lg fa-save" />

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection